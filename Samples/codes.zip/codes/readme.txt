Copyright (c) 2021 Showa Denko Materials co., Ltd. All rights reserved.

This software is for non-profit use only.

THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THIS SOFTWARE OR THE USE OR OTHER DEALINGS IN THIS SOFTWARE.


List of provided data and codes

 -matopt_review: Python3 codes for multi-objective Bayesian optimization.
  See also fllowing three Jupyter notebook samples.

 -Example_of_running_benchmarks_with_toy_problems_using_achievement_LCB.ipynb: Jupyter notebook sample for running benchmarks with the baseline method.

 -Example_of_running_benchmarks_with_toy_problems_using_PA.ipynb: Jupyter notebook sample for running benchmarks with the proposed method.

 -Example_of_running_virtual_inverse_material_design.ipyn: Jupyter notebook sample for running the virtual inverse material design.
